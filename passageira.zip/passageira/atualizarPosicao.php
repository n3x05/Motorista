<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$date = date("d/m/Y");
$horario = date("H:i:s");
$pedido = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$rowPedido = mysqli_fetch_object($pedido);
$pedidoUsuarioLatitude = $rowPedido->pedido_usuario_latitude;
$pedidoUsuarioLongitude = $rowPedido->pedido_usuario_longitude;
$q=mysqli_query($con,"SELECT profissional_id, profissional_latitude, profissional_longitude, 
    SQRT( POW(69.1 * (profissional_latitude - $pedidoUsuarioLatitude), 2) + 
    POW(69.1 * ($pedidoUsuarioLongitude - profissional_longitude) * COS(profissional_latitude / 57.3), 2)) AS distancia 
    FROM profissional HAVING distancia < 2 ORDER BY distancia");
while($row = mysqli_fetch_object($q)){
    $profissionalId = $row->profissional_id;
    $u=mysqli_query($con,"UPDATE profissional SET profissional_pedido = '$pedidoId' WHERE profissional_id = '$profissionalId' AND profissional_status = '1'");   
}