<?php
date_default_timezone_set("America/Sao_Paulo");
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$status=mysqli_query($con,"SELECT pedido_status, pedido_cancelamento_inicio, pedido_cancelamento_fim FROM pedido "
    . "WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($status);
$pedido = $row->pedido_status;
$pedidoCancelamentoInicio = $row->pedido_cancelamento_inicio;
$pedidoCancelamentoFim = $row->pedido_cancelamento_fim;
$h = new DateTime();
$pedidoHorario = $h->format('H:i');
if($pedidoHorario == $pedidoCancelamentoFim){
    mysqli_query($con,"UPDATE pedido SET "
    . "pedido_cancelamento_inicio = '$pedidoCancelamentoFim' "
    . "WHERE pedido_id = '$pedidoId'");    
}
$data[] = [
    "pedido" => $pedido,
    "pedidoH" => $pedidoCancelamentoInicio,
    "pedidoC" => $pedidoCancelamentoFim
];
echo json_encode($data);