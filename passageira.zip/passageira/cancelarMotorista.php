<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$qi = mysqli_query($con,"SELECT profissional_status FROM profissional WHERE profissional_status = '$usuarioId'");
$qirow = mysqli_num_rows($qi);
if($qirow > 0){
    $u=mysqli_query($con,"UPDATE profissional SET profissional_status = '1' WHERE profissional_status = '$usuarioId'");    
}
    $data[] = [
        "id" => $qirow
    ];    
echo json_encode($data);