<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$profissionalId'"
        );
$row = mysqli_fetch_object($q);
$email = $row->profissional_email;
if($email){
    #Início: Enviar Email
    $mensagem = "<center><h1><b>Usuária solicitou uma corrida!</b></h1></center>";
    $destinatarios = $email;
    $nomeDestinatario = "A motorista";
    $usuario = '';
    $senha = '';

    $nomeRemetente = "A motorista";
    $assunto = "Pedido de corrida!";

    include_once("../_lib/phpmailer/PHPMailerAutoload.php");

    $To = $destinatarios;
    $Subject = $assunto;
    $Message = $mensagem;
    $Host = 'mail.' . substr(strstr($usuario, '@'), 1);
    $Username = $usuario;
    $Password = $senha;
    $Port = "587";
    $mail = new PHPMailer();
    $body = $Message;

    $mail->IsSMTP(); // telling the class to use SMTP

    $mail->Host = $Host; // SMTP server 

    $mail->SMTPDebug = 0; // enables SMTP debug information (for testing) 
// 1 = errors and messages 
// 2 = messages only 

    $mail->SMTPAuth = true; // enable SMTP authentication 

    $mail->Port = $Port; // set the SMTP port for the service server 

    $mail->Username = $Username; // account username 

    $mail->Password = $Password; // account password 

    $mail->SetFrom($usuario, $nomeDestinatario);
    $mail->Subject = $Subject;
    $mail->MsgHTML($body);
    $mail->AddAddress($To, "");

    $mail->AddAttachment($anexo, $anexo);
//$mail->AddAttachment($anexo['tmp_name'], $anexo['name']  );

    if (!$mail->Send()) {
        //$mensagemRetorno = 'Erro ao enviar e-mail: ' . print($mail->ErrorInfo);
    } else {
        //echo $mensagemRetorno = 'E-mail enviado com sucesso!';
    }
    # Fim: Enviar Email
}
