<?php
include_once '../_database/database.php';
$email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
$senha = sha1(filter_input(INPUT_GET, 'senha', FILTER_SANITIZE_SPECIAL_CHARS));
$usuarioCadastro = "1";
$stmt = mysqli_prepare($con, "SELECT usuario_id, usuario_email FROM usuario "
        . "WHERE usuario_email = ? AND usuario_senha = ? AND usuario_cadastro = ?");
mysqli_stmt_bind_param($stmt, "ssi", $email, $senha, $usuarioCadastro);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $usuarioId, $usuarioEmail);
mysqli_stmt_fetch($stmt);

$data[] = [
    "usuarioId" => $usuarioId,
    "usuarioEmail" => $usuarioEmail
]; 
echo json_encode($data);
mysqli_free_result($stmt);
mysqli_close($con);