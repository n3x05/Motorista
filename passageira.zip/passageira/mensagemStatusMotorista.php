<?php
include_once '../_database/database.php';
$msg = utf8_encode(filter_input(INPUT_GET, 'msg', FILTER_SANITIZE_SPECIAL_CHARS));
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioEmail = filter_input(INPUT_GET, 'usuarioEmail', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
if($msg == "1"){
    $u2=mysqli_query($con,"UPDATE profissional SET profissional_status = '0' WHERE profissional_id = '$profissionalId'");   
}
if($msg == "2"){
    $u2=mysqli_query($con,"UPDATE profissional SET profissional_status = '1' WHERE profissional_id = '$profissionalId'");   
}
$data[] = [
    "msg" => $msg
];
echo json_encode($data);