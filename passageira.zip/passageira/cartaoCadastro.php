<?php
include_once '../_database/database.php';
require_once ('mp/lib/mercadopago.php');
//AnneProdução
$mp = new MP('');
$token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
//$customerId = filter_input(INPUT_POST, 'customerId', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_POST, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$saved_customer = $mp->get ("/v1/customers/search", $customer2);
$customer_id = $saved_customer["response"]["results"][0]["id"];
if($customer_id == null){
    $customer1 = $mp->post("/v1/customers", array("email" => $email)); 
    $saved_customer = $mp->get ("/v1/customers/search", array ("email" => $email));
    $customer_id = $saved_customer["response"]["results"][0]["id"];    
}
$card = $mp->post ("/v1/customers/".$customer_id."/cards", array("token" => $token));
mysqli_query($con,"INSERT INTO cartao (cartao_usuario, cartao_email, cartao_empresa) VALUES('$usuarioId', '$email', '1')");
$q1 = mysqli_query($con,"SELECT * FROM cartao WHERE cartao_usuario = '$usuarioId'");
$row1 = mysqli_fetch_object($q1);
$cartaoId = $row1->cartao_id;
mysqli_query($con,"UPDATE usuario SET usuario_pagamento = '12', usuario_cartao_id = '$cartaoId' WHERE usuario_id = '$usuarioId'");
$cadastro = "1";
$data[] = [
  "cadastro" => $cadastro
];    
echo json_encode($data);
