<?php
include_once '../_database/database.php';
$mpA = mysqli_query($con,"SELECT * FROM profissional WHERE profissional_status != '0'");
$total = mysqli_num_rows($mpA);
while($row = mysqli_fetch_object($mpA)){
$latitude[] = $row->profissional_latitude;
$longitude[] = $row->profissional_longitude;    
}
$data[] = [
    "latitude" => $latitude,
    "longitude" => $longitude,
    "total" => $total
];
echo json_encode($data);