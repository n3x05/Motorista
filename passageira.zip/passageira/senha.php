<?php
include_once '../_database/database.php';
$k = filter_input(INPUT_GET, 'k', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * "
        . "FROM usuario "
        . "WHERE usuario_email = '$email' AND usuario_senha = '$k'"
        );
$row = mysqli_fetch_object($q);
if($row->usuario_id){
    ?>
    <html>
        <head>          
            <link rel="stylesheet" href= "../_lib/bootstrap-3.3.7-dist/css/bootstrap.min.css">
            <link rel="stylesheet" href="../_lib/bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
            <link rel="stylesheet" type="text/css" href="_lib/jquery-ui-1.11.4/jquery-ui.css"> 
            <script src="../_lib/jquery-1.12.2.js"></script>   
            <script src="../_lib/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script> 
            <script src=".../_lib/bootbox.min.js"></script>
            <script src="../_lib/jquery-ui-1.11.4/jquery-ui.js"></script>    
            <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body style="background: #b5143e;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">&nbsp;</div>
                </div>  
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><center><img src="../_img/logo.png" width="150"></center></div>
                </div> 
                <br>
                <div class="jumbotron" style="background-color: transparent; width: 100%; margin: 0 auto; text-align: center">
                    <form class="form-horizontal" method="post" action="senhaAlterar.php">
                        <div class="form-group">
                            <div class="col-xs-12 col-sm-10 col-md-12 col-lg-12">
                                <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $row->usuario_id;?>">
                                <input type="password" class="form-control input-lg" id="senha" name="senha" placeholder="Senha" required="">
                            </div>
                        </div>           
                        <div class="form-group">
                            <div class="col-xs-0 col-sm-10 col-md-12 col-lg-12">
                                <button type="submit" class="btn btn-lg btn-block btn-danger">Alterar</button>
                            </div>
                        </div>
                    </form>
                </div>             
            </div> 
        </body>    
    </html>
    <?php
}else{
    ?>
    <html style="background: #b5143e no-repeat center center fixed; background-size:100% 100%; height: 100%">
        <head>          
            <link rel="stylesheet" href= "../_lib/bootstrap-3.3.7-dist/css/bootstrap.min.css">
            <link rel="stylesheet" href="../_lib/bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
            <link rel="stylesheet" type="text/css" href="../_lib/jquery-ui-1.11.4/jquery-ui.css"> 
            <script src="../_lib/jquery-1.12.2.js"></script>   
            <script src="../_lib/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script> 
            <script src="../_lib/bootbox.min.js"></script>
            <script src="../_lib/jquery-ui-1.11.4/jquery-ui.js"></script>    
            <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">&nbsp;</div>
                </div>  
                <br>
                <div class="jumbotron" style="width: 100%; margin: 0 auto; text-align: center">
                    <h1>Página não encontrada!</h1>
                </div>             
            </div> 
        </body>    
    </html>
    <?php
}