<?php
date_default_timezone_set("America/Sao_Paulo");
include_once '../_database/database.php';
$longitude = filter_input(INPUT_GET, 'longitude', FILTER_SANITIZE_SPECIAL_CHARS);
$latitude = filter_input(INPUT_GET, 'latitude', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$origem = utf8_decode(filter_input(INPUT_GET, 'origem', FILTER_SANITIZE_SPECIAL_CHARS));
$destino = utf8_decode(filter_input(INPUT_GET, 'destino', FILTER_SANITIZE_SPECIAL_CHARS));
$valor = filter_input(INPUT_GET, 'valor', FILTER_SANITIZE_SPECIAL_CHARS);
$existe = filter_input(INPUT_GET, 'existe', FILTER_SANITIZE_SPECIAL_CHARS);
$date = date("d/m/Y");
$dataPesquisa = date("Ymd");
//$horario = date("H:i:s");

$h = new DateTime();

$horario = $h->format('H:i');

$h->add(new DateInterval('PT5M'));

$pedidoCancelamentoFim = $h->format('H:i');

if ($existe == "1") {
    $q = mysqli_query($con, "SELECT * FROM profissional WHERE profissional_status = '$usuarioId'");
    $row = mysqli_fetch_object($q);
    $profissionalId = $row->profissional_id;

    $qi = mysqli_query($con, "SELECT pedido_id FROM pedido WHERE pedido_usuario = '$usuarioId' AND pedido_profissional = '$profissionalId' ORDER BY pedido_id DESC LIMIT 1");
    $qirow = mysqli_fetch_object($qi);
    $pedidoId = $qirow->pedido_id;
} else {
//$apagarPedido = mysqli_query($con,"DELETE FROM pedido WHERE pedido_usuario = '$usuarioId' AND pedido_profissional = '0'");
    $q = mysqli_query($con, "SELECT * FROM profissional WHERE profissional_status = '$usuarioId'");
    $row = mysqli_fetch_object($q);
    $profissionalId = $row->profissional_id;
    
    $porc1 = mysqli_query($con, "SELECT * FROM porcentagem WHERE porcentagem_id = '1'");
    $porc2 = mysqli_fetch_object($porc1);
    $porc = $porc2->porcentagem_valor; 
    
    $desc1 = mysqli_query($con, "SELECT * FROM porcentagem WHERE porcentagem_id = '2'");
    $desc2 = mysqli_fetch_object($desc1);
    $desc = $desc2->porcentagem_valor;  

    $bonus1 = mysqli_query($con, "SELECT * FROM porcentagem WHERE porcentagem_id = '3'");
    $bonus2 = mysqli_fetch_object($bonus1);
    $bonus = $bonus2->porcentagem_valor;      
    
    if ($profissionalId) {
        $i = mysqli_query($con, "INSERT INTO pedido ("
                . "pedido_data, "
                . "pedido_data_pesquisa, "
                . "pedido_horario, "
                . "pedido_cancelamento_inicio, "
                . "pedido_cancelamento_fim, "
                . "pedido_usuario, "
                . "pedido_profissional, "
                . "pedido_valor, "
                . "pedido_usuario_latitude, "
                . "pedido_usuario_longitude, "
                . "pedido_usuario_origem, "
                . "pedido_usuario_destino, "
                . "pedido_porcentagem, "
                . "pedido_desconto, "
                . "pedido_bonus, "
                . "pedido_status, "
                . "pedido_avaliacao, "
                . "pedido_comentario, "
                . "pedido_usuario_avaliacao, "
                . "pedido_usuario_comentario, "
                . "pedido_pagamento, "
                . "pedido_profissional_motivo, "
                . "pedido_usuario_motivo) "
                . "VALUES ("
                . "'$date', "
                . "'$dataPesquisa', "
                . "'$horario', "
                . "'$horario', "
                . "'$pedidoCancelamentoFim', "
                . "'$usuarioId', "
                . "'$profissionalId', "
                . "'$valor', "
                . "'$latitude', "
                . "'$longitude', "
                . "'$origem', "
                . "'$destino',"
                . "'$porc', "
                . "'$desc', "
                . "'$bonus', "
                . "'0', "
                . "'0', "
                . "'', "
                . "'0', "
                . "'', "
                . "'0', "
                . "'', "
                . "'')");
        $qi = mysqli_query($con, "SELECT pedido_id FROM pedido WHERE pedido_usuario = '$usuarioId' AND pedido_profissional = '$profissionalId' ORDER BY pedido_id DESC LIMIT 1");
        $qirow = mysqli_fetch_object($qi);
        $pedidoId = $qirow->pedido_id;

        $pPedido = mysqli_query($con, "UPDATE profissional SET profissional_pedido = '$pedidoId' WHERE profissional_status = '$usuarioId'");
    }
}
$data[] = [
    "id" => $profissionalId,
    "nome" => utf8_encode($row->profissional_nome),
    "pedido" => $pedidoId
];

echo json_encode($data);