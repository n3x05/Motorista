<?php
include_once '../_database/database.php';
$categoria = filter_input(INPUT_GET, 'categoria', FILTER_SANITIZE_SPECIAL_CHARS);
$total = mysqli_query($con, "SELECT profissional_id FROM profissional");
$t = mysqli_num_rows($total);
$online = mysqli_query($con, "SELECT profissional_id FROM profissional WHERE profissional_status != '0'");
$o = mysqli_num_rows($online);
$pt = ($o * 100) / $t;
if($pt == 0){
    $dinamicoPorcentagem = 0;
}
if ($pt > 0 and $pt <= 25) {
    $dinamicoPorcentagem = 25;
}
if ($pt > 25 and $pt <= 50) {
    $dinamicoPorcentagem = 50;
}
if ($pt > 50 and $pt <= 75) {
    $dinamicoPorcentagem = 75;
}
if ($pt > 75 and $pt <= 100) {
    $dinamicoPorcentagem = 100;
}

$stmt = mysqli_prepare($con, "SELECT dinamico_valor FROM dinamico "
        . "WHERE dinamico_porcentagem = ?");
mysqli_stmt_bind_param($stmt, "i", $dinamicoPorcentagem);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $dinamicoValor);
mysqli_stmt_fetch($stmt);

$data[] = [
    "dinamicoValor" => $dinamicoValor
];

echo json_encode($data);

mysqli_free_result($total);
mysqli_free_result($online);
//mysqli_free_result($q);
mysqli_free_result($stmt);

mysqli_close($con);