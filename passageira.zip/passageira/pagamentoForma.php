<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$forma = filter_input(INPUT_GET, 'forma', FILTER_SANITIZE_SPECIAL_CHARS);
//Escolha do pagamento
if ($forma == '1') {
    //buscar a forma de pagamento e no caso em cartão, a empresa
    $q1 = mysqli_query($con, "SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
    $row1 = mysqli_fetch_object($q1);
    $usuarioEscolhaPagamento = $row1->usuario_escolha_pagamento;
    $usuarioCartaoId = $row1->usuario_cartao_id;

    //Dinheiro
    if ($usuarioEscolhaPagamento == '1') {
        $data[] = [
            "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento
        ];
        echo json_encode($data);
    }

    //Dinheiro
    if ($usuarioEscolhaPagamento == '3') {
        $data[] = [
            "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento
        ];
        echo json_encode($data);
    }    
    
    //Cartão de Crédito
    if ($usuarioEscolhaPagamento == '2') {
        //buscar o email do cartão e a empresa
        $c1 = mysqli_query($con, "SELECT * FROM cartao WHERE cartao_usuario = '$usuarioId' AND cartao_id = '$usuarioCartaoId'");
        $rowC1 = mysqli_fetch_object($c1);
        $cartaoEmpresa = $rowC1->cartao_empresa;
        $cartaoEmail = $rowC1->cartao_email;
        //MercadoPago
        if ($cartaoEmpresa == '1') {
            require_once ('mp/lib/mercadopago.php');
            //Anne Produção
            $mp = new MP('');

            $filters = array("email" => $cartaoEmail);
            $customer = $mp->get("/v1/customers/search", $filters);
            //print_r($customer["response"]["results"]);
            $qtd = count(isset($customer["response"]["results"]));
            for ($i = 0; $i <= $qtd - 1; $i++) {
                $cartaoId[] = $customer["response"]["results"][$i]["cards"][$i]["id"];
                $first_six_digits[] = $customer["response"]["results"][$i]["cards"][$i]["first_six_digits"];
                $security_code_length[] = $customer["response"]["results"][$i]["cards"][$i]["security_code"]["length"];
                $payment_method_name[] = $customer["response"]["results"][$i]["cards"][$i]["payment_method"]["name"];
                $last_four_digits[] = $customer["response"]["results"][$i]["cards"][$i]["last_four_digits"];
                $customerId[] = $customer['response']['results'][0]['cards'][0]['customer_id'];
            }
            $customerId = $customer['response']['results'][0]['cards'][0]['customer_id'];
            $data[] = [
                "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento,
                "cartaoEmpresa" => $cartaoEmpresa,
                "cartaoEmail" => $cartaoEmail,
                "cartaoId" => $cartaoId,
                "first_six_digits" => $first_six_digits,
                "security_code_length" => $security_code_length,
                "payment_method_name" => $payment_method_name,
                "last_four_digits" => $last_four_digits,
                "customerId" => $customerId,
                "qtd" => $qtd
            ];
            echo json_encode($data);
        }
    }
}

//Mostrar forma de pagamento
if ($forma == '2') {
    //buscar as formas de pagamentos cadastrados
    $q1 = mysqli_query($con, "SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
    $row1 = mysqli_fetch_object($q1);
    $usuarioPagamento = $row1->usuario_pagamento;
    $data[] = [
        "usuarioPagamento" => $usuarioPagamento
    ];
    echo json_encode($data);
}

//Alterar forma de pagamento para dinheiro
if ($forma == '3') {
    mysqli_query($con, "UPDATE usuario SET usuario_escolha_pagamento = '1'  WHERE usuario_id = '$usuarioId'");
    $data[] = [
        "forma" => $forma
    ];
    echo json_encode($data);
}

//Alterar forma de pagamento para cartão de crédito
if ($forma == '4') {
    mysqli_query($con, "UPDATE usuario SET usuario_escolha_pagamento = '2'  WHERE usuario_id = '$usuarioId'");
    $data[] = [
        "forma" => $forma
    ];
    echo json_encode($data);
}

//Confirmar pagamento em dinheiro
if ($forma == '5') {
    $pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
    $d1 = mysqli_query($con, "SELECT pedido_status, pedido_valor, pedido_profissional FROM pedido WHERE pedido_id = '$pedidoId'");
    $d2 = mysqli_fetch_object($d1);
    $pedidoStatus = $d2->pedido_status;
    $pedidoProfissional = $d2->pedido_profissional;
    $p1 = mysqli_query($con, "SELECT profissional_status FROM profissional WHERE profissional_id = '$pedidoProfissional'");
    $p2 = mysqli_fetch_object($p1);
    $profissionalStatus = $p2->profissional_status;
    if ($profissionalStatus == "1") {
        $msgPgto = "Pagamento confirmado!";
    } else {
        $msgPgto = "Aguardando a confirmação de pagamento.";
    }
    
    $c1 = mysqli_query($con, "SELECT SUM(cancelamento_extrato_valor) as cancelamentoExtratoValor FROM cancelamento_extrato WHERE cancelamento_extrato_usuario = '$usuarioId' AND cancelamento_extrato_status = '1'");
    $c2 = mysqli_fetch_object($c1);
    
    if($c2->cancelamentoExtratoValor != null){
        $pedidoValor1 = $d2->pedido_valor + $c2->cancelamentoExtratoValor;    
    
        $pedidoValor = "R$ " . $d2->pedido_valor . " + R$ " . $c2->cancelamentoExtratoValor . "(taxa de cancelamento)<br><br>Total: R$" . $pedidoValor1;
    }
    else{
        $pedidoValor1 = $d2->pedido_valor;    
    
        $pedidoValor = "R$ " . $pedidoValor1;        
    }
    $data[] = [
        "profissionalStatus" => $profissionalStatus,
        "pedidoValor" => $pedidoValor,
        "msgPgto" => $msgPgto
    ];
    echo json_encode($data);
}

//Alterar forma de pagamento para cartão de crédito
if ($forma == '6') {
    mysqli_query($con, "UPDATE usuario SET usuario_escolha_pagamento = '3'  WHERE usuario_id = '$usuarioId'");
    $data[] = [
        "forma" => $forma
    ];
    echo json_encode($data);
}
