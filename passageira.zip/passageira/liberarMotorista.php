<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$qi = mysqli_query($con,"SELECT * FROM profissional WHERE profissional_status = '$usuarioId' AND profissional_id = '$profissionalId'");
$qirow = mysqli_num_rows($qi);
if($qirow == "0"){
mysqli_query($con,"UPDATE profissional SET profissional_status = '1' WHERE profissional_status = '$usuarioId'");
$liberado = "2";
}else{
mysqli_query($con,"UPDATE profissional SET profissional_status = '1' WHERE profissional_status = '$usuarioId'");
mysqli_query($con,"UPDATE profissional SET profissional_status = '$usuarioId' WHERE profissional_id = '$profissionalId'");
$liberado = "1";    
}
$data[] = [
    "liberado" => $liberado
];
echo json_encode($data);
mysqli_free_result($qi);
mysqli_close($con);