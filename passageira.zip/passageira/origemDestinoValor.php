<?php
include_once '../_database/database.php';

$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$mpA = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($mpA);
$usuarioId = $row->pedido_usuario;

$pU = mysqli_query($con,"SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
$pU1 = mysqli_fetch_object($pU);
$origem = utf8_encode($row->pedido_usuario_origem);
$destino = utf8_encode($row->pedido_usuario_destino);
$valor = $row->pedido_valor;
$usuarioPagamento = $pU1->usuario_pagamento;
$usuarioEscolhaPagamento = $pU1->usuario_escolha_pagamento;

$data[] = [
    "origem" => $origem,
    "destino" => $destino, 
    "valor" => $valor,
    "usuarioPagamento" => $usuarioPagamento,
    "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento
];

echo json_encode($data);