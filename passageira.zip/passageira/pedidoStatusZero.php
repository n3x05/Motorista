<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$apagarPedido = mysqli_query($con,"DELETE FROM pedido WHERE pedido_usuario = '$usuarioId' AND pedido_status='0'");
$u=mysqli_query($con,"UPDATE profissional SET profissional_status = '1', profissional_pedido = '0', profissional_passageiro = '0' WHERE profissional_status = '$usuarioId'");