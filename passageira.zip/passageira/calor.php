<?php
date_default_timezone_set('America/Sao_Paulo');
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$latitude = filter_input(INPUT_GET, 'latitude', FILTER_SANITIZE_SPECIAL_CHARS);
$longitude = filter_input(INPUT_GET, 'longitude', FILTER_SANITIZE_SPECIAL_CHARS);
$data = date("Y-m-d H:i:s");
mysqli_query($con,"UPDATE calor SET calor_status = '2' WHERE calor_usuario = '$usuarioId'");
mysqli_query($con,"INSERT INTO calor (calor_usuario, calor_latitude, calor_longitude, calor_status, calor_data) VALUES('$usuarioId', '$latitude', '$longitude', '1', '$data')");
$status = "1";
$data[] = [
    "status" => $status
];
echo json_encode($data);