<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$avaliacao = filter_input(INPUT_GET, 'avaliacao', FILTER_SANITIZE_SPECIAL_CHARS);
$pI1=mysqli_query($con,"SELECT pedido_profissional FROM pedido "
        . "WHERE pedido_id = '$pedidoId'");
$pI2 = mysqli_fetch_object($pI1);
$profissionalId = $pI2->pedido_profissional;
$q=mysqli_query($con,"UPDATE pedido SET pedido_avaliacao = '$avaliacao' "
        . "WHERE pedido_id = '$pedidoId'"
        );
$s=mysqli_query($con,"SELECT SUM(pedido_avaliacao) as soma FROM pedido "
        . "WHERE pedido_profissional = '$profissionalId'"
        );
$row = mysqli_fetch_object($s);
$soma = $row->soma;
$t=mysqli_query($con,"SELECT pedido_avaliacao FROM pedido "
        . "WHERE pedido_profissional = '$profissionalId' AND pedido_avaliacao != '0'"
        ); 
$total = mysqli_num_rows($t);
$media = $soma / $total;
$p=mysqli_query($con,"UPDATE profissional SET profissional_avaliacao = '$media' "
        . "WHERE profissional_id = '$profissionalId'"
        );