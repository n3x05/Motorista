<?php
include_once '../_database/database.php';
$v=mysqli_query($con,"SELECT cancelamento_valor FROM cancelamento "
    . "WHERE cancelamento_id = '1'");
$row = mysqli_fetch_object($v);
$cancelarValor = $row->cancelamento_valor;
$data[] = [
    "cancelarValor" => $cancelarValor
];
echo json_encode($data);