<?php
include_once '../_database/database.php';
require_once ('mp/lib/mercadopago.php');

//Anne Produção Token
$mp = new MP('');

$token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_SPECIAL_CHARS);
$customerId = filter_input(INPUT_POST, 'customerId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_POST, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);

$q = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$profissionalId = $row->pedido_profissional;
$pedidoValor1 = (float) $row->pedido_valor;

$passageiraId = $row->pedido_usuario;
$c = mysqli_query($con,"SELECT SUM(cancelamento_extrato_valor) as cancelamentoExtratoValor FROM cancelamento_extrato "
. "WHERE cancelamento_extrato_usuario = '$passageiraId'");
$rowC = mysqli_fetch_object($c);
if($rowC->cancelamentoExtratoValor == null){
    $pedidoValor = $pedidoValor1;   
}else{
    $cancelamentoValor = (float) $rowC->cancelamentoExtratoValor;

    $pedidoValor = $pedidoValor1 + $cancelamentoValor;      
}


$payment_data = array(
	"transaction_amount" => $pedidoValor,
	"token" => $token,
	"description" => $pedidoId,
	"installments" => 1,
	"payer" => array (
		"type" => "customer",
        "id" => $customerId
	)
);

$payment = $mp->post("/v1/payments", $payment_data);
$paymentId = $payment["response"]["id"];
//print_r($payment);

$verificar = $mp->get("/v1/payments/$paymentId");
$verificarId = $verificar["response"]["status"];
//print_r($verificar);

if(isset($paymentId)){
mysqli_query($con,"UPDATE pedido SET pedido_pagamento = '$paymentId', pedido_status = '1' WHERE pedido_id = '$pedidoId'");

mysqli_query($con,"UPDATE profissional SET profissional_pedido = '0', profissional_status = '1' WHERE profissional_id = '$profissionalId'");

mysqli_query($con,"UPDATE cancelamento_extrato SET cancelamento_extrato_profissional_saida = '$profissionalId', cancelamento_extrato_status = '$pedidoId' WHERE cancelamento_extrato_usuario = '$passageiraId' AND cancelamento_extrato_status = '1'");
}

$data[] = [
  "verificarId" => $verificarId
];    
echo json_encode($data);
