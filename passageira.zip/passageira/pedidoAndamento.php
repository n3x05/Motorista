<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$uid = mysqli_query($con, "SELECT * "
        . "FROM profissional "
        . "WHERE profissional_status = '$usuarioId'"
);
$uid1 = mysqli_num_rows($uid);
if ($uid1 > 0) {
    $uid2 = mysqli_fetch_object($uid);
    $pedidoId = $uid2->profissional_pedido;
    $categoria = $uid2->profissional_categoria;
    $profissionalId = $uid2->profissional_id;
    $profissionalNome = utf8_encode($uid2->profissional_nome);
    
    //pedido
    $pedido1 = mysqli_query($con, "SELECT * "
            . "FROM pedido "
            . "WHERE pedido_id = '$pedidoId'"
    );
    $pedido2 = mysqli_fetch_object($pedido1);
    $lat = $pedido2->pedido_usuario_latitude;
    $lang = $pedido2->pedido_usuario_longitude;
    $vt = $pedido2->pedido_valor;
    $endereco = utf8_encode($pedido2->pedido_usuario_destino);
    
    //usuário
    $usuario1 = mysqli_query($con, "SELECT * "
            . "FROM usuario "
            . "WHERE usuario_id = '$usuarioId'"
    );
    $usuario2 = mysqli_fetch_object($usuario1);
    $usuarioEmail = $usuario2->usuario_email;
    
    $data[] = [
        "pedidoId" => $pedidoId,
        "usuarioId" => $usuarioId,
        "usuarioEmail" => $usuarioEmail,
        "lat" => $lat,
        "lang" => $lang,
        "categoria" => $categoria,
        "profissionalId" => $profissionalId,
        "profissionalNome" => $profissionalNome,        
        "valor" => $vt,
        "endereco" => $endereco
    ];
} else {
    $pedidoId = "0";
    $data[] = [
        "pedidoId" => $pedidoId
    ];
}
echo json_encode($data);