<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
$row = mysqli_fetch_object($q);
$usuarioPagamento = $row->usuario_pagamento;
$data[] = [
    "usuarioPagamento" => $usuarioPagamento
];    
echo json_encode($data);