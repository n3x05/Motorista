<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$cv = mysqli_query($con,"SELECT SUM(cancelamento_extrato_valor) as cancelamentoExtratoValor FROM cancelamento_extrato "
        . "WHERE cancelamento_extrato_usuario = '$usuarioId' AND cancelamento_extrato_status = '1'");
$row = mysqli_fetch_object($cv);
$cancelamentoValor = $row->cancelamentoExtratoValor;
$data[] = [
    "cancelamentoValor" => $cancelamentoValor
];
echo json_encode($data);