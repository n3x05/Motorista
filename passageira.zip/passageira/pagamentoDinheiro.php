<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con, "SELECT pedido_status FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$pedidoStatus = $row->pedido_status;
if ($pedidoStatus == "4") {
    mysqli_query($con, "UPDATE pedido SET pedido_status = '1' WHERE pedido_id = '$pedidoId'");
    mysqli_query($con, "UPDATE profissional SET profissional_status = '1', profissional_pedido = '0' WHERE profissional_pedido = '$pedidoId'");
}
if ($pedidoStatus == "0") {
    mysqli_query($con, "UPDATE pedido SET pedido_status = '3' WHERE pedido_id = '$pedidoId'");
    mysqli_query($con, "UPDATE profissional SET profissional_status = '1', profissional_pedido = '0' WHERE profissional_pedido = '$pedidoId'");
}