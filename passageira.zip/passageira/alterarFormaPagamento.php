<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$forma = filter_input(INPUT_GET, 'forma', FILTER_SANITIZE_SPECIAL_CHARS);
//Escolha do pagamento
if($forma == '1'){
mysqli_query($con,"UPDATE usuario SET usuario_escolha_pagamento = '1'  WHERE usuario_id = '$usuarioId'");
}
if($forma == '2'){
mysqli_query($con,"UPDATE usuario SET usuario_escolha_pagamento = '2'  WHERE usuario_id = '$usuarioId'");
}