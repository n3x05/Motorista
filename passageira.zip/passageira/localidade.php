<?php
include_once '../_database/database.php';
$longitude = filter_input(INPUT_GET, 'longitude', FILTER_SANITIZE_SPECIAL_CHARS);
$latitude = filter_input(INPUT_GET, 'latitude', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$origem = utf8_decode(filter_input(INPUT_GET, 'origem', FILTER_SANITIZE_SPECIAL_CHARS));
$destino = utf8_decode(filter_input(INPUT_GET, 'destino', FILTER_SANITIZE_SPECIAL_CHARS));
$valor = filter_input(INPUT_GET, 'valor', FILTER_SANITIZE_SPECIAL_CHARS); 
$date = date("d/m/Y");
$horario = date("H:i:s");
$apagarPedido = mysqli_query($con,"DELETE FROM pedido WHERE pedido_usuario = '$usuarioId' AND pedido_profissional = '0'");
$i = mysqli_query($con,"INSERT INTO pedido (pedido_data, pedido_horario, pedido_usuario, pedido_valor, pedido_usuario_latitude, pedido_usuario_longitude, pedido_usuario_origem, pedido_usuario_destino) VALUES ('$date', '$horario', '$usuarioId', '$valor', '$latitude', '$longitude', '$origem', '$destino')");
$qi = mysqli_query($con,"SELECT pedido_id FROM pedido WHERE pedido_usuario = '$usuarioId' AND pedido_profissional = '0' ORDER BY pedido_usuario DESC LIMIT 1");
$qirow = mysqli_fetch_object($qi);
$pedidoId = $qirow->pedido_id;
$q=mysqli_query($con,"SELECT profissional_id, profissional_latitude, profissional_longitude, 
    SQRT( POW(69.1 * (profissional_latitude - $latitude), 2) + 
    POW(69.1 * ($longitude - profissional_longitude) * COS(profissional_latitude / 57.3), 2)) AS distancia 
    FROM profissional HAVING distancia < 2 ORDER BY distancia");
while($row = mysqli_fetch_object($q)){
    $profissionalId = $row->profissional_id;
    $u=mysqli_query($con,"UPDATE profissional SET profissional_pedido = '$pedidoId' WHERE profissional_id = '$profissionalId' AND profissional_status = '1'");
    $data[] = [
        "id" => $profissionalId,
        "nome" => utf8_encode($row->profissional_nome),
        "pedido" => $pedidoId
    ];    
}
echo json_encode($data);