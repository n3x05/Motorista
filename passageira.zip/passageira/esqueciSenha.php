<?php
include_once '../_database/database.php';
$email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * "
        . "FROM usuario "
        . "WHERE usuario_email = '$email'"
        );
$row = mysqli_fetch_object($q);
if($row->usuario_id){
    #Início: Enviar Email
    $mensagem = "<center><h1><b>Clique no link para alterar a senha.</b></h1></center>"
                . "<center><h2><a href='senha.php?email=" . $email . "&k=" . $row->usuario_senha . "'>Alterar senha</a></h2></center>";
    $destinatarios = $email;
    $nomeDestinatario = "A motorista";
    $usuario = '';
    $senha = '';
    $nomeRemetente = "A motorista";
    $assunto = "Esqueci senha";
    include_once("../_lib/phpmailer/PHPMailerAutoload.php");
    $To = $destinatarios;
    $Subject = $assunto;
    $Message = $mensagem;
    $Host = 'mail.' . substr(strstr($usuario, '@'), 1);
    $Username = $usuario;
    $Password = $senha;
    $Port = "587";
    $mail = new PHPMailer();
    $body = $Message;
    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->Host = $Host; // SMTP server 
    $mail->SMTPDebug = 0; // enables SMTP debug information (for testing) 
    // 1 = errors and messages 
    // 2 = messages only 
    $mail->SMTPAuth = true; // enable SMTP authentication 
    $mail->Port = $Port; // set the SMTP port for the service server 
    $mail->Username = $Username; // account username 
    $mail->Password = $Password; // account password 
    $mail->SetFrom($usuario, $nomeDestinatario);
    $mail->Subject = $Subject;
    $mail->MsgHTML($body);
    $mail->AddAddress($To, "");
    $mail->AddAttachment($anexo, $anexo);
    //$mail->AddAttachment($anexo['tmp_name'], $anexo['name']  );
    if (!$mail->Send()) {
        //$mensagemRetorno = 'Erro ao enviar e-mail: ' . print($mail->ErrorInfo);
    } else {
        //echo $mensagemRetorno = 'E-mail enviado com sucesso!';
    }
    # Fim: Enviar Email
}
$data[] = [
    "id" => $row->usuario_id,
    "nome" => $row->usuario_nome
];
echo json_encode($data);
