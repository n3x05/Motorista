<?php
include_once '../_database/database.php';

$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);

$up = mysqli_query($con,"UPDATE profissional SET profissional_status = '$usuarioId'"
        . "WHERE profissional_id = '$profissionalId'");

$p = mysqli_query($con,"SELECT * FROM profissional "
        . "WHERE profissional_id = '$profissionalId'");
$row = mysqli_fetch_object($p);
$profissionalLatitude = $row->profissional_latitude;
$profissionalLongitude = $row->profissional_longitude;
$data[] = [
    "profissionalLatitude" => $profissionalLatitude,
    "profissionalLongitude" => $profissionalLongitude
];

echo json_encode($data);