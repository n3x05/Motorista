<?php
include_once '../_database/database.php';
$latUsuario = filter_input(INPUT_GET, 'latUsuario', FILTER_SANITIZE_SPECIAL_CHARS);
$longUsuario = filter_input(INPUT_GET, 'longUsuario', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
#selecionar a escolha do pagamento
$pE1 = mysqli_query($con, "SELECT usuario_escolha_pagamento "
        . "FROM usuario "
        . "WHERE usuario_id = '$usuarioId'"
);
$pE2 = mysqli_fetch_object($pE1);
$pagamentoEscolha = $pE2->usuario_escolha_pagamento;
#atualizar a latitude e longitude da passageira
mysqli_query($con, "UPDATE usuario "
        . "SET usuario_latitude = '$latUsuario', usuario_longitude = '$longUsuario' "
        . "WHERE usuario_id = '$usuarioId'");
#selecionar a motorista com status da id da passageira
$uid = mysqli_query($con, "SELECT * "
        . "FROM profissional "
        . "WHERE profissional_status = '$usuarioId'"
);
#quantidade de motoristas com status da id da passageira
$uid1 = mysqli_num_rows($uid);
#se quantidade for maior que zero
if ($uid1 > 0) {
    #número do pedido
    $uid2 = mysqli_fetch_object($uid);
    $pedidoId = $uid2->profissional_pedido;

    if ($uid2->profissional_passageiro == "0") {
        mysqli_query($con, "UPDATE profissional "
                . "SET profissional_status = '1', profissional_pedido = '0' "
                . "WHERE profissional_status = '$usuarioId'"
        );
        mysqli_query($con, "UPDATE pedido "
                . "SET pedido_status = '3' "
                . "WHERE pedido_id = '$pedidoId'"
        );
        $profissionalId4 = $uid2->profissional_id;
        $categoria4 = $uid2->profissional_categoria;
        $disponivel4 = "4";
    } else {
        $p1 = mysqli_query($con, "SELECT * "
                . "FROM pedido "
                . "WHERE pedido_id = '$pedidoId'"
        );
        $p2 = mysqli_fetch_object($p1);

        $id = $p2->pedido_profissional;
        $nome = utf8_encode($uid2->profissional_nome);
        $lat = $p2->pedido_usuario_latitude;
        $lang = $p2->pedido_usuario_longitude;
        $valor = $p2->pedido_valor;

        $profissionalId5 = $uid2->profissional_id;
        $categoria5 = $uid2->profissional_categoria;
        $disponivel5 = "5";
    }
}
#se quantidade de motoristas com status de id das passageiras for mmenor que zero
else {

    function distancia($lat1, $lon1, $lat2, $lon2) {
        $lat1 = deg2rad($lat1);
        $lat2 = deg2rad($lat2);
        $lon1 = deg2rad($lon1);
        $lon2 = deg2rad($lon2);

        $dist = (6371 * acos(cos($lat1) * cos($lat2) * cos($lon2 - $lon1) + sin($lat1) * sin($lat2)) );
        $dist = number_format($dist, 2, '.', '');
        return $dist;
    }

    if ($pagamentoEscolha == "1") {
        $d1 = mysqli_query($con, "SELECT * "
                . "FROM profissional "
                . "WHERE profissional_status = '1' AND profissional_categoria = '1' AND profissional_forma_pagamento != '2'"
        );
    }

    if ($pagamentoEscolha == "2") {
        $d1 = mysqli_query($con, "SELECT * "
                . "FROM profissional "
                . "WHERE profissional_status = '1' AND profissional_categoria = '1'"
        );
    }

    if ($pagamentoEscolha == "3") {
        $d1 = mysqli_query($con, "SELECT * "
                . "FROM profissional "
                . "WHERE profissional_status = '1' AND profissional_categoria = '1' AND profissional_forma_pagamento = '3'"
        );
    }

    $motoristaDisponivel1 = mysqli_num_rows($d1);
    if ($motoristaDisponivel1 > 0) {
        while ($rowDist = mysqli_fetch_object($d1)) {
            $latProfissional = $rowDist->profissional_latitude;
            $longProfissional = $rowDist->profissional_longitude;
            $distancia = distancia($latUsuario, $longUsuario, $latProfissional, $longProfissional);
            $atendimento = $rowDist->profissional_atendimento;
            if ($atendimento >= $distancia) {
                $profissionalId[] = $rowDist->profissional_id;
                $distancia1[] = $distancia;
                $atendimento1[] = $atendimento;
                $categoria[] = $rowDist->profissional_categoria;
            }
        }
        if ($profissionalId) {
            $menorDist = min($distancia1);
            $qtde = count($distancia1);

            for ($q = 0; $q <= $qtde; $q++) {
                if ($categoria[$q] == "1") {
                    if ($distancia1[$q] == $menorDist) {
                        //$u = mysqli_query($con, "UPDATE profissional SET "
                        //      . "profissional_status = '$usuarioId' WHERE "
                        //      . "profissional_id = '$profissionalId[$q]'"
                        // );
                        $disponivel1 = "2";
                        $categoria1 = "1";
                        $profissionalId1 = $profissionalId[$q];
                    }
                }
            }
        } else {
            $disponivel1 = "1";
        }
    } else {
        $disponivel1 = "1";
    }

    $d2 = mysqli_query($con, "SELECT * "
            . "FROM profissional "
            . "WHERE profissional_status = '1' AND profissional_categoria = '2'"
    );
    $motoristaDisponivel2 = mysqli_num_rows($d2);
    if ($motoristaDisponivel2 > 0) {
        while ($rowDist = mysqli_fetch_object($d2)) {
            $latProfissional = $rowDist->profissional_latitude;
            $longProfissional = $rowDist->profissional_longitude;
            $distancia = distancia($latUsuario, $longUsuario, $latProfissional, $longProfissional);
            $atendimento = $rowDist->profissional_atendimento;
            if ($atendimento >= $distancia) {
                $profissionalId[] = $rowDist->profissional_id;
                $distancia1[] = $distancia;
                $atendimento1[] = $atendimento;
                $categoria[] = $rowDist->profissional_categoria;
            }
        }
        if ($profissionalId) {
            $menorDist = min($distancia1);
            $qtde = count($distancia1);

            for ($q = 0; $q <= $qtde; $q++) {
                if ($categoria[$q] == "2") {
                    if ($distancia1[$q] == $menorDist) {
                        //$u = mysqli_query($con, "UPDATE profissional SET "
                        //      . "profissional_status = '$usuarioId' WHERE "
                        //      . "profissional_id = '$profissionalId[$q]'"
                        // );
                        $disponivel2 = "2";
                        $categoria2 = "2";
                        $profissionalId2 = $profissionalId[$q];
                    }
                }
            }
        } else {
            $disponivel2 = "1";
        }
    } else {
        $disponivel2 = "1";
    }

    $d3 = mysqli_query($con, "SELECT * "
            . "FROM profissional "
            . "WHERE profissional_status = '1' AND profissional_categoria = '3'"
    );
    $motoristaDisponivel3 = mysqli_num_rows($d3);
    if ($motoristaDisponivel3 > 0) {
        while ($rowDist = mysqli_fetch_object($d3)) {
            $latProfissional = $rowDist->profissional_latitude;
            $longProfissional = $rowDist->profissional_longitude;
            $distancia = distancia($latUsuario, $longUsuario, $latProfissional, $longProfissional);
            $atendimento = $rowDist->profissional_atendimento;
            if ($atendimento >= $distancia) {
                $profissionalId13[] = $rowDist->profissional_id;
                $distancia13[] = $distancia;
                $atendimento13[] = $atendimento;
                $categoria13[] = $rowDist->profissional_categoria;
            }
        }
        if ($profissionalId13) {
            $menorDist13 = min($distancia13);
            $qtde13 = count($distancia13);
            for ($q13 = 0; $q13 <= $qtde13 - 1; $q13++) {
                if ($categoria13[$q13] == "3") {
                    if ($distancia13[$q13] == $menorDist13) {
                        //$u = mysqli_query($con, "UPDATE profissional SET "
                        //      . "profissional_status = '$usuarioId' WHERE "
                        //      . "profissional_id = '$profissionalId[$q]'"
                        // );
                        $disponivel3 = "2";
                        $categoria3 = "3";
                        $profissionalId3 = $profissionalId13[$q13];
                    }
                }
            }
        } else {
            $disponivel3 = "1";
        }
    } else {
        $disponivel3 = "1";
    }
}

$data[] = [
    "disponivel1" => $disponivel1,
    "disponivel2" => $disponivel2,
    "disponivel3" => $disponivel3,
    "disponivel4" => $disponivel4,
    "disponivel5" => $disponivel5,
    "categoria1" => $categoria1,
    "categoria2" => $categoria2,
    "categoria3" => $categoria3,
    "categoria4" => $categoria4,
    "categoria5" => $categoria5,
    "profissionalId1" => $profissionalId1,
    "profissionalId2" => $profissionalId2,
    "profissionalId3" => $profissionalId3,
    "profissionalId4" => $profissionalId4,
    "profissionalId5" => $profissionalId5,
    "id" => $id,
    "nome" => $nome,
    "lat" => $lat,
    "lang" => $lang,
    "valor" => $valor,
    "pedidoId" => $pedidoId
];

echo json_encode($data);

mysqli_free_result($uid);
mysqli_free_result($p1);
mysqli_free_result($d1);
mysqli_free_result($d2);
mysqli_free_result($d3);

mysqli_close($con);