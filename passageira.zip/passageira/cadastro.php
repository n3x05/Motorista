<?php
date_default_timezone_set('America/Sao_Paulo');
include_once '../_database/database.php';

$nome = utf8_decode(filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS));
$sexo = filter_input(INPUT_POST, 'sexo', FILTER_SANITIZE_SPECIAL_CHARS);
$sexoNome = utf8_decode(filter_input(INPUT_POST, 'sexoNome', FILTER_SANITIZE_SPECIAL_CHARS));
$sexoIdade = filter_input(INPUT_POST, 'sexoIdade', FILTER_SANITIZE_SPECIAL_CHARS);
$ddd = filter_input(INPUT_POST, 'ddd', FILTER_SANITIZE_SPECIAL_CHARS);
$telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
$senha = sha1(filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_SPECIAL_CHARS));
$endereco = utf8_decode(filter_input(INPUT_POST, 'endereco', FILTER_SANITIZE_SPECIAL_CHARS));
$numero = filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_SPECIAL_CHARS);
$complemento = utf8_decode(filter_input(INPUT_POST, 'complemento', FILTER_SANITIZE_SPECIAL_CHARS));
$bairro = utf8_decode(filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_SPECIAL_CHARS));
$cep = utf8_decode(filter_input(INPUT_POST, 'cep', FILTER_SANITIZE_SPECIAL_CHARS));
$cidade = utf8_decode(filter_input(INPUT_POST, 'cidade', FILTER_SANITIZE_SPECIAL_CHARS));
$estado = utf8_decode(filter_input(INPUT_POST, 'estado', FILTER_SANITIZE_SPECIAL_CHARS));

$data1 = date("Y-m-d H:i:s");
//verificar se o email foi cadastrado
$q = mysqli_query($con, "SELECT * "
        . "FROM usuario "
        . "WHERE usuario_email = '$email' AND usuario_cadastro = '1'"
);
$row = mysqli_fetch_object($q);
if ($row->usuario_id) {
    $mensagem = "1";
    $data[] = [
        "mensagem" => $mensagem
    ];
    echo json_encode($data);
} else {    
    
    mysqli_query($con, "DELETE FROM usuario WHERE usuario_email = '$email' AND usuario_cadastro = '0'");
    
    $i = mysqli_query($con, "INSERT INTO usuario "
            . "(usuario_nome, "         
            . "usuario_sexo, "
            . "usuario_sexo_nome, "
            . "usuario_sexo_idade, "
            . "usuario_ddd, "
            . "usuario_telefone, "            
            . "usuario_email, "
            . "usuario_senha, "
            . "usuario_endereco, "
            . "usuario_numero, "
            . "usuario_complemento, "
            . "usuario_bairro, "
            . "usuario_cep, "
            . "usuario_cidade, "
            . "usuario_estado, "
            . "usuario_pagamento, "
            . "usuario_escolha_pagamento, "
            . "usuario_avaliacao, "
            . "usuario_cadastro, "
            . "usuario_cadastro_data) "
            . "VALUES"
            . "('$nome', "
            . "'$sexo', "
            . "'$sexoNome', "
            . "'$sexoIdade', "
            . "'$ddd', "            
            . "'$telefone', "            
            . "'$email', "            
            . "'$senha', "            
            . "'$endereco', "
            . "'$numero', "
            . "'$complemento', "
            . "'$bairro', "
            . "'$cep', "
            . "'$cidade', "
            . "'$estado', "           
            . "'1', "
            . "'1', "
            . "'0', "
            . "'0', "
            . "'$data1')"
    );
    $user = mysqli_query($con, "SELECT * "
            . "FROM usuario "
            . "WHERE usuario_email = '$email'"
    );
    $linha = mysqli_fetch_object($user);
    $usuarioId = $linha->usuario_id;
    $mensagem = "2";

    $data[] = [
        "usuarioId" => $usuarioId,
        "usuarioEmail" => $email,
        "mensagem" => $mensagem
    ];
    echo json_encode($data);
}