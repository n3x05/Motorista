<?php
include_once '../_database/database.php';
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$profissionalId' AND pedido_comentario != ''");
while($row = mysqli_fetch_object($q)){
   $date[] = $row->pedido_data;
   $comentario[] = utf8_encode($row->pedido_comentario);
}
$data[] = [
    "comentario" => $comentario,
    "date" => $date
];
echo json_encode($data);