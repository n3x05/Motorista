<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$comentario = utf8_encode(filter_input(INPUT_GET, 'comentario', FILTER_SANITIZE_SPECIAL_CHARS));
mysqli_query($con,"UPDATE pedido SET pedido_comentario = '$comentario' "
    . "WHERE pedido_id = '$pedidoId'"
);