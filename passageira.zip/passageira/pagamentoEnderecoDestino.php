<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$mpA = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($mpA);
$enderecoDestino = utf8_encode($row->pedido_usuario_destino);
$valor = $row->pedido_valor;
$data[] = [
    "enderecoDestino" => $enderecoDestino,
    "valor" => $valor
];
echo json_encode($data);