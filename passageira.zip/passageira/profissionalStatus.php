<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$up = mysqli_query($con,"UPDATE profissional SET profissional_status = '$usuarioId'"
        . "WHERE profissional_id = '$profissionalId'");