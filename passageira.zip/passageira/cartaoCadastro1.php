<?php
require_once ('mp/lib/mercadopago.php');
//Anne produção
$mp = new MP('');
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
//$mp->post("/v1/customers", array("email" => $email));
$saved_customer = $mp->get ("/v1/customers/search", array ("email" => $email));
$customer_id = $saved_customer["response"]["results"][0]["id"];
if($customer_id == null){
    $mp->post("/v1/customers", array("email" => $email));
    $saved_customer = $mp->get ("/v1/customers/search", array ("email" => $email));
    $customer_id = $saved_customer["response"]["results"][0]["id"];    
}
$data[] = [
  "cadastro" => $customer_id
];    
echo json_encode($data);
