<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedido = mysqli_query($con,"SELECT pedido_id, pedido_profissional FROM pedido WHERE pedido_usuario = '$usuarioId' ORDER BY pedido_id DESC LIMIT 1");
$row = mysqli_fetch_object($pedido);
$pedidoId = $row->pedido_id;
$pedidoProfissional = $row->pedido_profissional;
$data[] = [
    "pedidoId" => $pedidoId,
    "pedidoProfissional" => $pedidoProfissional
];
echo json_encode($data);