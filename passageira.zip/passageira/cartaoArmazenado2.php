<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_POST, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$profissionalId = $row->pedido_profissional;
mysqli_query($con,"UPDATE pedido SET pedido_status = '1' WHERE pedido_id = '$pedidoId'");
mysqli_query($con,"UPDATE profissional SET profissional_pedido = '0', profissional_status = '1' WHERE profissional_id = '$profissionalId'");
$data[] = [
  "verificarId" => $verificarId
];
echo json_encode($data);