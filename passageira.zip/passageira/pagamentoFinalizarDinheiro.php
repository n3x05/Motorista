<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$pedidoPagamento = $row->pedido_pagamento;
$data[] = [
    "pedidoPagamento" => $pedidoPagamento
];    
echo json_encode($data);