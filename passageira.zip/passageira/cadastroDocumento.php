<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$rg = filter_input(INPUT_GET, 'rg', FILTER_SANITIZE_SPECIAL_CHARS);
$cpf = utf8_decode(filter_input(INPUT_GET, 'cpf', FILTER_SANITIZE_SPECIAL_CHARS));
mysqli_query($con, "UPDATE usuario SET "
. "usuario_rg =  '$rg', "
. "usuario_cpf = '$cpf' "
. "WHERE usuario_id = '$usuarioId'");
$cadastro = "1";
$data[] = [
    "cadastro" => $cadastro
];
echo json_encode($data);