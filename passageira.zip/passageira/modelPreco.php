<?php
include_once '../_database/database.php';

$categoria = filter_input(INPUT_GET, 'categoria', FILTER_SANITIZE_SPECIAL_CHARS);

$stmt = mysqli_prepare($con, "SELECT preco_distancia, preco_tempo FROM preco "
        . "WHERE preco_categoria = ?");
mysqli_stmt_bind_param($stmt, "i", $categoria);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $precoDistancia, $precoTempo);
mysqli_stmt_fetch($stmt);

$data[] = [
    "distancia" => $precoDistancia,
    "tempo" => $precoTempo
    
];

echo json_encode($data);

mysqli_free_result($stmt);
mysqli_close($con);