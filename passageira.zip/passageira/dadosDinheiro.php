<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
//Update tabela pedido
mysqli_query($con,"UPDATE pedido "
        . "SET pedido_status = '1' "
        . "WHERE pedido_id = '$pedidoId'"
        );
//Update tabela profissional
mysqli_query($con,"UPDATE profissional "
        . "SET profissional_status = '1', "
	. "profissional_pedido = '0', "
	. "profissional_passageiro = '0' "
        . "WHERE profissional_pedido = '$pedidoId'"
        );