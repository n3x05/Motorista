<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$apagarPedido = mysqli_query($con,"DELETE FROM pedido WHERE pedido_id = '$pedidoId'");
$u=mysqli_query($con,"UPDATE profissional SET profissional_pedido = '0' WHERE profissional_pedido = '$pedidoId'");
$mensagem = "Pedido cancelado.";
$data[] = [
    "mensagem" => $mensagem
];
echo json_encode($data);