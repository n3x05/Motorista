<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
$row = mysqli_fetch_object($q);
$usuarioEscolhaPagamento = $row->usuario_escolha_pagamento;
$data[] = [
    "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento
];    
echo json_encode($data);

