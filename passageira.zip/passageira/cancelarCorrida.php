<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$valor = filter_input(INPUT_GET, 'valor', FILTER_SANITIZE_SPECIAL_CHARS);
$cancelar = filter_input(INPUT_GET, 'cancelar', FILTER_SANITIZE_SPECIAL_CHARS);
if($cancelar == "1") {
    mysqli_query($con, "UPDATE profissional SET "
    . "profissional_status = '1', "
    . "profissional_passageiro = '0', "            
    . "profissional_pedido = '0' "
    . "WHERE profissional_id = '$profissionalId'");    
    
    mysqli_query($con, "UPDATE pedido SET "
    . "pedido_status = '5' "
    . "WHERE pedido_id = '$pedidoId'");

}
if($cancelar == "2") {
    mysqli_query($con, "INSERT INTO cancelamento_extrato("
    . "cancelamento_extrato_pedido, "
    . "cancelamento_extrato_usuario, "
    . "cancelamento_extrato_profissional_entrada, "
    . "cancelamento_extrato_valor, "
    . "cancelamento_extrato_status) "
    . "VALUES("
    . "'$pedidoId', "
    . "'$usuarioId', "
    . "'$profissionalId', "
    . "'$valor', "
    . "'1')");
    mysqli_query($con, "UPDATE profissional SET "
    . "profissional_status = '1', "
    . "profissional_passageiro = '0', "                
    . "profissional_pedido = '0' "
    . "WHERE profissional_id = '$profissionalId'");
    mysqli_query($con, "UPDATE pedido SET "
    . "pedido_status = '5' "
    . "WHERE pedido_id = '$pedidoId'");    
}
$data[] = [
    "pedido" => $pedidoId
];
echo json_encode($data);