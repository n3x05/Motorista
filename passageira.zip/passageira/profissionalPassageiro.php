<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pp = mysqli_query($con,"SELECT * FROM profissional WHERE profissional_status = '$usuarioId'");
$row = mysqli_fetch_object($pp);
$passageiro = $row->profissional_passageiro;
$data[] = [
    "passageiro" => $passageiro
];    
echo json_encode($data);