<?php
include_once '../_database/database.php';
$q=mysqli_query($con,"SELECT * "
        . "FROM tarifa_base "
        . "WHERE tarifa_base_id = '1'"
        );
$row = mysqli_fetch_object($q);
$data[] = [
    "tarifaBase" => $row->tarifa_base_valor
]; 
echo json_encode($data);