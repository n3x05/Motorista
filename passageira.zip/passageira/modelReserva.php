<?php
include_once '../_database/database.php';
$reserva_usuario = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$reserva_origem = utf8_encode(filter_input(INPUT_GET, 'origemEndereco', FILTER_SANITIZE_SPECIAL_CHARS));
$reserva_destino = utf8_encode(filter_input(INPUT_GET, 'destinoEndereco', FILTER_SANITIZE_SPECIAL_CHARS));
$reserva_data = filter_input(INPUT_GET, 'data', FILTER_SANITIZE_SPECIAL_CHARS);
$reserva_hora = filter_input(INPUT_GET, 'hora', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"INSERT INTO reserva "
        . "(reserva_usuario, "
        . "reserva_origem, "
        . "reserva_destino, "
        . "reserva_data, "
        . "reserva_hora) "
        . "VALUES('$reserva_usuario', "
        . "'$reserva_origem', "
        . "'$reserva_destino', "
        . "'$reserva_data', "
        . "'$reserva_hora')");
$data[] = [
    "reserva_usuario" => $reserva_usuario
]; 
echo json_encode($data);