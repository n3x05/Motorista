<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pro=mysqli_query($con,"UPDATE pagamento SET "
        . "pagamento_status = '2' "
        . "WHERE pagamento_profissional = '$usuarioId'"
        );
$saldo = "Resgate solicitado com sucesso!";
$data[] = [
    "saldo" => $saldo
];
echo json_encode($data);