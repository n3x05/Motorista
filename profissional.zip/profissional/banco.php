<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$banco = utf8_decode(filter_input(INPUT_GET, 'banco', FILTER_SANITIZE_SPECIAL_CHARS));
$agencia = filter_input(INPUT_GET, 'agencia', FILTER_SANITIZE_SPECIAL_CHARS);
$conta = filter_input(INPUT_GET, 'conta', FILTER_SANITIZE_SPECIAL_CHARS);
$s = mysqli_query($con,"SELECT * FROM banco "
    . "WHERE banco_usuario = '$usuarioId'");
$linha = mysqli_num_rows($s);
if($linha){
	if($banco and $agencia and $conta){
	    $q=mysqli_query($con,"UPDATE banco SET "
		. "banco_nome='$banco', banco_agencia='$agencia', banco_conta='$conta' "
		. "WHERE banco_usuario = '$usuarioId'");
	    $u = mysqli_query($con,"SELECT * FROM banco "
		    . "WHERE banco_usuario = '$usuarioId'");
	    $rowU = mysqli_fetch_object($u);
	    $bancoNome = $rowU->banco_nome;
            $bancoAgencia = $rowU->banco_agencia;
	    $bancoConta = $rowU->banco_conta;
	}else{
	$row = mysqli_fetch_object($s);
	$bancoNome = $row->banco_nome;
        $bancoAgencia = $row->banco_agencia;
	$bancoConta = $row->banco_conta;
	}
}else{
    $q=mysqli_query($con,"INSERT INTO banco (banco_usuario, banco_nome, banco_agencia, banco_conta) VALUES('$usuarioId', '$banco', $agencia', '$conta')");  
}
$data[] = [
    "banco" => utf8_encode($bancoNome),
    "agencia" => $bancoAgencia,
    "conta" => $bancoConta
];
echo json_encode($data);