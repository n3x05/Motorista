<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * FROM pedido "
    . "WHERE pedido_id = '$pedidoId'"
    );
$row = mysqli_fetch_object($q);
$pedido_valor = $row->pedido_valor;
$pro=mysqli_query($con,"UPDATE profissional SET "
    . "profissional_pedido = '0' "
    . "WHERE profissional_pedido = '$pedidoId' "
    . "AND profissional_id != '$usuarioId'"
    );
$ped=mysqli_query($con,"UPDATE pedido SET "
    . "pedido_profissional = '$usuarioId' "
    . "WHERE pedido_id = '$pedidoId'"
    );
$data[] = [
    "pedido_valor" => $pedido_valor,
    "usuario_id" => $usuarioId
];
echo json_encode($data);