<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$rg = filter_input(INPUT_GET, 'rg', FILTER_SANITIZE_SPECIAL_CHARS);
$cpf = filter_input(INPUT_GET, 'cpf', FILTER_SANITIZE_SPECIAL_CHARS);
$cnh = filter_input(INPUT_GET, 'cnh', FILTER_SANITIZE_SPECIAL_CHARS);
mysqli_query($con,"UPDATE profissional SET "
    . "profissional_rg = '$rg', "
    . "profissional_cpf = '$cpf', "
    . "profissional_cnh = '$cnh' "
    . "WHERE profissional_id = '$usuarioId'");
$data[] = [
    "usuarioId" => $usuarioId
];
echo json_encode($data);