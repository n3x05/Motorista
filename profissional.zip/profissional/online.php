<?php
include_once '../_database/database.php';
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_SPECIAL_CHARS);
mysqli_query($con,"UPDATE profissional SET "
    . "profissional_status = '1' "
    . "WHERE profissional_id = '$id'"
    );
$data[] = [
    "id" => $id
];
echo json_encode($data);