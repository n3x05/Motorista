<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$usuarioId'"
        );
$row = mysqli_fetch_object($q);
$profissionalStatus = $row->profissional_status;
$data[] = [
    "profissionalStatus" => $profissionalStatus
];
echo json_encode($data);