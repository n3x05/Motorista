<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$update=mysqli_query($con,"UPDATE pedido SET pedido_status = '1' WHERE pedido_id = '$pedidoId'");
$q=mysqli_query($con,"SELECT * "
        . "FROM pedido "
        . "WHERE pedido_id = '$pedidoId'"
        );
$row = mysqli_fetch_object($q);
$pedidoStatus = $row->pedido_status;
$pedidoUsuario = $row->pedido_usuario;
$pedidoProfissional = $row->pedido_profissional;
$us1=mysqli_query($con,"SELECT * "
        . "FROM usuario "
        . "WHERE usuario_id = '$pedidoUsuario'"
        );
$us2 = mysqli_fetch_object($us1);
$usuarioEscolhaPagamento = $us2->usuario_escolha_pagamento;
$pro1=mysqli_query($con,"SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$pedidoProfissional'"
        );
$pro2 = mysqli_fetch_object($pro1);
$profissionalStatus = $pro2->profissional_status;
$c1=mysqli_query($con,"SELECT SUM(cancelamento_extrato_valor) as cancelamentoExtratoValor "
        . "FROM cancelamento_extrato "
        . "WHERE cancelamento_extrato_usuario = '$pedidoUsuario' AND cancelamento_extrato_status = '1'"
        );
$c2 = mysqli_fetch_object($c1);
$cancelamentoValor = $c2->cancelamentoExtratoValor;
$data[] = [
  "pedidoStatus" => $pedidoStatus,
  "pedidoUsuario" => $pedidoUsuario,
  "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento,
  "profissionalStatus" => $profissionalStatus,
  "cancelamentoValor" => $cancelamentoValor  
];
echo json_encode($data);