<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pro=mysqli_query($con,"SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$usuarioId'"
        );
$rowPro = mysqli_fetch_object($pro);
$ped=mysqli_query($con,"SELECT * "
        . "FROM pedido "
        . "WHERE pedido_profissional = '$usuarioId' AND pedido_status = '3'"
        );
$cancelada = mysqli_num_rows($ped);
$data[] = [
    "avaliacao" => $rowPro->profissional_avaliacao,
    "cancelada" => $cancelada
];
echo json_encode($data);