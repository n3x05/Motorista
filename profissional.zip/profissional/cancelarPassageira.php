<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT pedido_profissional FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$pedidoProfissional = $row->pedido_profissional;
$e = mysqli_query($con,"SELECT profissional_status FROM profissional WHERE profissional_id = '$pedidoProfissional'");
$rowE = mysqli_fetch_object($e);
$status = $rowE->profissional_status;
$data[] = [
    "status" => $status
];    
echo json_encode($data);