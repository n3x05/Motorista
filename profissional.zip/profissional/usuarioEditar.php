<?php
include_once '../_database/database.php';
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_SPECIAL_CHARS);
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
if($id == "1"){
    $q=mysqli_query($con,"SELECT * "
            . "FROM profissional "
            . "WHERE profissional_id = '$usuarioId'"
            );
    $row = mysqli_fetch_object($q);
    $nome = utf8_encode($row->profissional_nome);
    $email = $row->profissional_email;
    $ddd = $row->profissional_ddd;
    $telefone = $row->profissional_telefone;
    $cpf = $row->profissional_cpf;
    $endereco = utf8_encode($row->profissional_endereco);
    $numero = $row->profissional_numero;
    $complemento = utf8_encode($row->profissional_complemento);
    $bairro = utf8_encode($row->profissional_bairro);
    $cep = $row->profissional_cep;
    $cidade = utf8_encode($row->profissional_cidade);
    $estado = $row->profissional_estado;
    $data[] = [
        "nome" => $nome,
        "email" => $email,
	"ddd" => $ddd,
	"telefone" => $telefone,
	"cpf" => $cpf,
	"endereco" => $endereco,
	"numero" => $numero,
	"complemento" => $complemento,
	"bairro" => $bairro,
	"cep" => $cep,
	"cidade" => $cidade,
	"estado" => $estado
    ];
    echo json_encode($data);
}
if($id == "2"){
    $nome = utf8_encode(filter_input(INPUT_GET, 'nome', FILTER_SANITIZE_SPECIAL_CHARS));
    $email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
    $cpf = filter_input(INPUT_GET, 'cpf', FILTER_SANITIZE_SPECIAL_CHARS);
    $ddd = filter_input(INPUT_GET, 'ddd', FILTER_SANITIZE_SPECIAL_CHARS); 
    $telefone = filter_input(INPUT_GET, 'telefone', FILTER_SANITIZE_SPECIAL_CHARS);
    $endereco = utf8_encode(filter_input(INPUT_GET, 'endereco', FILTER_SANITIZE_SPECIAL_CHARS)); 
    $numero = filter_input(INPUT_GET, 'numero', FILTER_SANITIZE_SPECIAL_CHARS); 
    $complemento = utf8_encode(filter_input(INPUT_GET, 'complemento', FILTER_SANITIZE_SPECIAL_CHARS)); 
    $bairro = utf8_encode(filter_input(INPUT_GET, 'bairro', FILTER_SANITIZE_SPECIAL_CHARS));
    $cep = filter_input(INPUT_GET, 'cep', FILTER_SANITIZE_SPECIAL_CHARS); 
    $cidade = utf8_encode(filter_input(INPUT_GET, 'cidade', FILTER_SANITIZE_SPECIAL_CHARS)); 
    $estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_SPECIAL_CHARS);
    
    $u=mysqli_query($con,"UPDATE profissional "
        . "SET "
        . "profissional_nome = '$nome', "
        . "profissional_email = '$email', "
        . "profissional_cpf = '$cpf', "
        . "profissional_ddd = '$ddd', "
        . "profissional_telefone = '$telefone', "
        . "profissional_endereco = '$endereco', "
        . "profissional_numero = '$numero', "
        . "profissional_complemento = '$complemento', "
        . "profissional_bairro = '$bairro', "
        . "profissional_cep = '$cep', "
        . "profissional_cidade = '$cidade', "
        . "profissional_estado = '$estado' "
        . "WHERE profissional_id = '$usuarioId'"
    );
}