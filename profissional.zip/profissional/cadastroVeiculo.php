<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$marca = filter_input(INPUT_GET, 'marca', FILTER_SANITIZE_SPECIAL_CHARS);
$modelo = filter_input(INPUT_GET, 'modelo', FILTER_SANITIZE_SPECIAL_CHARS);
$ano = filter_input(INPUT_GET, 'ano', FILTER_SANITIZE_SPECIAL_CHARS);
$placa = filter_input(INPUT_GET, 'placa', FILTER_SANITIZE_SPECIAL_CHARS);
mysqli_query($con,"INSERT INTO carro "
    . "(carro_usuario, "
    . "carro_marca, "
    . "carro_modelo, "
    . "carro_ano, "
    . "carro_placa) "
    . "VALUES"
    . "('$usuarioId', "
    . "'$marca', "
    . "'$modelo', "
    . "'$ano', "
    . "'$placa')");

$data[] = [
    "usuarioId" => $usuarioId
];
echo json_encode($data);