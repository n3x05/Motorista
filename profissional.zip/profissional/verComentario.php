<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$s = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$usuarioId'");
while ($rowS = mysqli_fetch_object($s)) {
    $date[] = $rowS->pedido_data;
    $comentario[] = utf8_encode($rowS->pedido_comentario);
}
$data[] = [
    "date" => $date,
    "comentario" => $comentario
];

echo json_encode($data);