<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$ped=mysqli_query($con,"UPDATE pedido SET "
        . "pedido_status = '3' "
        . "WHERE pedido_id = '$pedidoId'"
        );
$pro=mysqli_query($con,"UPDATE profissional SET "
        . "profissional_passageiro = '1' "
        . "WHERE profissional_id = '$usuarioId'"
        );
$confirmado = "1";
$data[] = [
    "confirmado" => $confirmado
];
echo json_encode($data);