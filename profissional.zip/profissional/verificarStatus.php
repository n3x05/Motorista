<?php
include_once '../_database/database.php';
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * FROM profissional "
               . "WHERE profissional_id = '$id'"
               );
$row = mysqli_fetch_object($q);
$data[] = [
  "status" => $row->profissional_status,
  "pedido" => $row->profissional_pedido
];
echo json_encode($data);