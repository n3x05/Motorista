<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$origemLatitude = filter_input(INPUT_GET, 'origemLatitude', FILTER_SANITIZE_SPECIAL_CHARS);
$origemLongitude = filter_input(INPUT_GET, 'origemLongitude', FILTER_SANITIZE_SPECIAL_CHARS);
$hora = date("Y-m-d H:i:s"); 
$q=mysqli_query($con,"SELECT * "
        . "FROM rota "
        . "WHERE rota_pedido = '$pedidoId'"
        );
$count = mysqli_num_rows($q);
if($count == 0){
mysqli_query($con,"INSERT INTO "
        . "rota "
        . "(rota_pedido, rota_origem_latitude, rota_origem_longitude, rota_destino_latitude, rota_destino_longitude, rota_tempo_inicio, rota_tempo_final) VALUES('$pedidoId', '$origemLatitude', '$origemLongitude', '$origemLatitude', '$origemLongitude', '$hora', '$hora')"
        );
$rotaValor = "0";
$data[] = [
  "origemLatitude" => $origemLatitude,
  "origemLongitude" => $origemLongitude,
  "destinoLatitude" => $origemLatitude,
  "destinoLongitude" => $origemLongitude,
  "rotaValor" => $rotaValor  
];
}
else{
$row = mysqli_fetch_object($q);
$local1=mysqli_query($con,"SELECT * "
        . "FROM rota "
        . "WHERE rota_pedido = '$pedidoId'"
        );
$local2 = mysqli_fetch_object($local1);
$latitude = $local2->rota_destino_latitude;
$longitude = $local2->rota_destino_longitude;
$rotaValor = $local2->rota_valor;

mysqli_query($con,"UPDATE rota SET "
  . "rota_origem_latitude = '$latitude', rota_origem_longitude = '$longitude', rota_destino_latitude = '$origemLatitude', rota_destino_longitude = '$origemLongitude', rota_tempo_final = '$hora', rota_tempo_total = timediff('$hora', rota_tempo_inicio) "
  . "WHERE rota_pedido = '$pedidoId'"
);
$data[] = [
  "origemLatitude" => $latitude,
  "origemLongitude" => $longitude,
  "destinoLatitude" => $origemLatitude,
  "destinoLongitude" => $origemLongitude,
  "rotaValor" => $rotaValor    
];
}
echo json_encode($data);