<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$distancia = filter_input(INPUT_GET, 'distancia', FILTER_SANITIZE_SPECIAL_CHARS);
$local1 = mysqli_query($con, "SELECT * "
        . "FROM rota "
        . "WHERE rota_pedido = '$pedidoId'"
);
$local2 = mysqli_fetch_object($local1);
$distanciaOrigem = $local2->rota_distancia;
$origemLatitude = $local2->rota_origem_latitude;
$origemLongitude = $local2->rota_origem_longitude;
$destinoLatitude = $local2->rota_destino_latitude;
$destinoLongitude = $local2->rota_destino_longitude;
$rotaDistancia = $local2->rota_distancia;
$rotaTempoTotal = $local2->rota_tempo_total;
if ($origemLatitude != $destinoLatitude or $origemLongitude != $destinoLongitude) {
   $distanciaAtual = $distanciaOrigem + $distancia;
   //calcular valor
   if($distanciaAtual > 0){
       //pegar o id do profissional 
       $pedido1 = mysqli_query($con, "SELECT * "
        . "FROM pedido "
        . "WHERE pedido_id = '$pedidoId'"
        );
        $pedido2 = mysqli_fetch_object($pedido1);
        $profissionalId = $pedido2->pedido_profissional;  
        //pegar a categoria
        $profissional1 = mysqli_query($con, "SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$profissionalId'"
        );
        $profissional2 = mysqli_fetch_object($profissional1);
        $categoria = $profissional2->profissional_categoria; 
        //pegar o preço
        $categoria1 = mysqli_query($con, "SELECT * "
        . "FROM preco "
        . "WHERE preco_categoria = '$categoria'"
        );
        $categoria2 = mysqli_fetch_object($categoria1);
        $precoDistancia = $categoria2->preco_distancia;    
        $precoTempo = $categoria2->preco_tempo;
        $pd = ($distanciaAtual/1000) * $precoDistancia;
        $pt1 = explode(":",$rotaTempoTotal);
        $pt2 = $pt1[0] * 60;
        $pt3 = $pt2 + $pt1[1];
        $pt = $pt3 * $precoTempo;
        $rotaValor = $pd + $pt;
        mysqli_query($con, "UPDATE rota SET "
        . "rota_valor = '$rotaValor' "
        . "WHERE rota_pedido = '$pedidoId'"
        );
    }
    mysqli_query($con, "UPDATE rota SET "
            . "rota_distancia = '$distanciaAtual' "
            . "WHERE rota_pedido = '$pedidoId'"
    );
}