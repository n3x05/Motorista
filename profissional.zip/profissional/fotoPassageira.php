<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$usuarioId = $row->pedido_usuario;
$usuarioValor = $row->pedido_valor;
$usuarioOrigem = utf8_encode($row->pedido_usuario_origem);
$usuarioDestino = utf8_encode($row->pedido_usuario_destino);
$e = mysqli_query($con,"SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
$rowE = mysqli_fetch_object($e);
$usuarioNome = utf8_encode($rowE->usuario_nome);
$data[] = [
    "fotoId" => $usuarioId,
    "nomePassageira" => $usuarioNome,
    "origemPassageira" => $usuarioOrigem,
    "destinoPassageira" => $usuarioDestino	
];    
echo json_encode($data);