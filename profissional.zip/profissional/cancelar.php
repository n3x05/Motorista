<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$motivo = filter_input(INPUT_GET, 'motivo', FILTER_SANITIZE_SPECIAL_CHARS);
$pro=mysqli_query($con,"UPDATE profissional SET "
    . "profissional_pedido = '0' "
    . "WHERE profissional_id = '$usuarioId'"
    );
$pedido=mysqli_query($con,"UPDATE pedido SET "
    . "pedido_status = '2' "
    . "WHERE pedido_id = '$pedidoId'"
    );
$user=mysqli_query($con,"SELECT * FROM profissional "
    . "WHERE profissional_id = '$usuarioId'"
    );
$row = mysqli_fetch_object($user);
$cancelar = $row->profissional_status;
$data[] = [
    "cancelar" => $cancelar
];
if($motivo){
mysqli_query($con,"UPDATE pedido SET "
    . "pedido_profissional_motivo = '$motivo' "
    . "WHERE pedido_id = '$pedidoId'"
    );    
}
echo json_encode($data);