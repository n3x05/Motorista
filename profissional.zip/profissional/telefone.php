<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedido=mysqli_query($con,"SELECT * FROM pedido "
    . "WHERE pedido_id = '$pedidoId'"
    );
$row1 = mysqli_fetch_object($pedido);
$usuarioId = $row1->pedido_usuario;
$usuario=mysqli_query($con,"SELECT * FROM usuario "
    . "WHERE usuario_id = '$usuarioId'"
    );
$row2 = mysqli_fetch_object($usuario);
$ddd = $row2->usuario_ddd;
$phone = $row2->usuario_telefone;
$data[] = [
    "ddd" => $ddd,
    "phone" => $phone
];
echo json_encode($data);