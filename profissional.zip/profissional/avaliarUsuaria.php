<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$passageiraId = filter_input(INPUT_GET, 'passageiraId', FILTER_SANITIZE_SPECIAL_CHARS);
$avaliacao = filter_input(INPUT_GET, 'avaliacao', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"UPDATE pedido SET pedido_usuario_avaliacao = '$avaliacao' "
        . "WHERE pedido_id = '$pedidoId'"
        );
$s=mysqli_query($con,"SELECT SUM(pedido_usuario_avaliacao) as soma FROM pedido "
        . "WHERE pedido_usuario = '$passageiraId'"
        );
$row = mysqli_fetch_object($s);
$soma = $row->soma;
$t=mysqli_query($con,"SELECT pedido_usuario_avaliacao FROM pedido "
        . "WHERE pedido_usuario = '$passageiraId' AND pedido_usuario_avaliacao != '0'"
        ); 
$total = mysqli_num_rows($t);
$media = $soma / $total;
$p=mysqli_query($con,"UPDATE usuario SET usuario_avaliacao = '$media' "
        . "WHERE usuario_id = '$passageiraId'"
        );