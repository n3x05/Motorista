<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$passageiraId = filter_input(INPUT_GET, 'passageiraId', FILTER_SANITIZE_SPECIAL_CHARS);
mysqli_query($con,"UPDATE pedido SET pedido_status = '1' WHERE pedido_id = '$pedidoId'");
mysqli_query($con,"UPDATE profissional SET profissional_status = '1', profissional_pedido = '0', profissional_passageiro = '0' WHERE profissional_id = '$usuarioId'");
mysqli_query($con,"UPDATE cancelamento_extrato SET cancelamento_extrato_profissional_saida = '$usuarioId', cancelamento_extrato_status = '$pedidoId' WHERE cancelamento_extrato_usuario = '$passageiraId' AND cancelamento_extrato_status = '1'");