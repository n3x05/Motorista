<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$dataInicial = filter_input(INPUT_GET, 'dataInicial', FILTER_SANITIZE_SPECIAL_CHARS);
$dataFinal = filter_input(INPUT_GET, 'dataFinal', FILTER_SANITIZE_SPECIAL_CHARS);
$inicial = $dataInicial[0] . $dataInicial[1] . $dataInicial[2] . $dataInicial[3] . $dataInicial[5] . $dataInicial[6] . $dataInicial[8] . $dataInicial[9];
$final = $dataFinal[0] . $dataFinal[1] . $dataFinal[2] . $dataFinal[3] . $dataFinal[5] . $dataFinal[6] . $dataFinal[8] . $dataFinal[9];
if ($dataInicial != null and $dataFinal != null) {
    $s = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_data_pesquisa >='$inicial' AND pedido_data_pesquisa <= '$final'");
    $t = mysqli_query($con, "SELECT SUM(pedido_valor) as total FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_data_pesquisa >='$inicial' AND pedido_data_pesquisa <= '$final' AND pedido_status = '1'");
}
if ($dataInicial != null and $dataFinal == null) {
    $s = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_data_pesquisa >='$inicial'");
    $t = mysqli_query($con, "SELECT SUM(pedido_valor) as total FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_data_pesquisa >='$inicial' AND pedido_status = '1'");
}
if ($dataInicial == null and $dataFinal != null) {
    $s = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_data_pesquisa <= '$final'");
    $t = mysqli_query($con, "SELECT SUM(pedido_valor) as total FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_data_pesquisa <= '$final' AND pedido_status = '1'");
}
if ($dataInicial == null and $dataFinal == null) {
    $s = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$usuarioId'");
    $t = mysqli_query($con, "SELECT SUM(pedido_valor) as total FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_status = '1'");
}
$linha = mysqli_num_rows($s);
if ($linha) {
    while ($rowS = mysqli_fetch_object($s)) {
        $date[] = $rowS->pedido_data;
        $valor[] = $rowS->pedido_valor;
        $origem[] = utf8_encode($rowS->pedido_usuario_origem);
        $destino[] = utf8_encode($rowS->pedido_usuario_destino);
        $comentario[] = utf8_encode($rowS->pedido_usuario_comentario);
        if ($rowS->pedido_status == "1") {
            $status[] = "Corrida paga";
        }
        if ($rowS->pedido_status == "2") {
            $status[] = "Motorista cancelou a viagem";
        }
        if ($rowS->pedido_status == "4") {
            $status[] = "Motorista não aceitou a viagem";
        }
        if ($rowS->pedido_status == "5") {
            $status[] = "Cancelado pela passageira";
        }
    }
    $rowT = mysqli_fetch_object($t);
    $total = $rowT->total;
} else {
    $resultado = "Sem valores";
}
$data[] = [
    "date" => $date,
    "valor" => $valor,
    "origem" => $origem,
    "destino" => $destino,
    "status" => $status,
    "comentario" => $comentario,
    "total" => $total
];
echo json_encode($data);