<?php
include_once '../_database/database.php';
$email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
$senha = sha1(filter_input(INPUT_GET, 'senha', FILTER_SANITIZE_SPECIAL_CHARS));
$profissionalCadastro = "1";
$stmt = mysqli_prepare($con, "SELECT profissional_id, profissional_nome FROM profissional "
        . "WHERE profissional_email = ? AND profissional_senha = ? AND profissional_cadastro = ?");
mysqli_stmt_bind_param($stmt, "ssi", $email, $senha, $profissionalCadastro);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $profissionalId, $profissionalNome);
mysqli_stmt_fetch($stmt);
$data[] = [
    "id" => $profissionalId,
    "nome" => utf8_encode($profissionalNome)
];
echo json_encode($data);
mysqli_free_result($stmt);
mysqli_close($con);