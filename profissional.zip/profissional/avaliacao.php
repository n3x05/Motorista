<?php
include_once '../_database/database.php';
$profissionalId = filter_input(INPUT_GET, 'profissionalId', FILTER_SANITIZE_SPECIAL_CHARS);
$q=mysqli_query($con,"SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$profissionalId'"
        );
$row = mysqli_fetch_object($q);
  
$data[] = [
    "avaliacao" => $row->profissional_avaliacao
];
echo json_encode($data);
mysqli_free_result($q);
mysqli_close($con);