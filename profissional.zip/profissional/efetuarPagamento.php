<?php
include_once '../_database/database.php';
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con,"SELECT * FROM pedido WHERE pedido_id = '$pedidoId'");
$row = mysqli_fetch_object($q);
$usuarioId = $row->pedido_usuario;
$usuarioValor = $row->pedido_valor;
$e = mysqli_query($con,"SELECT * FROM usuario WHERE usuario_id = '$usuarioId'");
$rowE = mysqli_fetch_object($e);
$usuarioEmail = $rowE->usuario_email;
$usuarioEscolhaPagamento = $rowE->usuario_escolha_pagamento;
$data[] = [
    "passageiraId" => $usuarioId,
    "passageiraEmail" => $usuarioEmail,
    "passageiraValor" => $usuarioValor,
    "usuarioEscolhaPagamento" => $usuarioEscolhaPagamento
];    
echo json_encode($data);