<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
mysqli_query($con,"UPDATE pedido SET "
    . "pedido_status = '1'"
    . "WHERE pedido_id = '$pedidoId'"
    );
$pro=mysqli_query($con,"UPDATE profissional SET "
    . "profissional_passageiro = '0',"
    . "profissional_pedido = '0',"
    . "profissional_status = '1' "
    . "WHERE profissional_id = '$usuarioId'"
    );
$q=mysqli_query($con,"SELECT * "
        . "FROM profissional "
        . "WHERE profissional_id = '$usuarioId'"
        );
$row = mysqli_fetch_object($q);
$data[] = [
    "nome" => utf8_encode($row->profissional_nome)
];
echo json_encode($data);