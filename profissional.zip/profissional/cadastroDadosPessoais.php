<?php
date_default_timezone_set('America/Sao_Paulo');
include_once '../_database/database.php';
$nomeCompleto = utf8_decode(filter_input(INPUT_GET, 'nomeCompleto', FILTER_SANITIZE_SPECIAL_CHARS));
$email = filter_input(INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS);
$senha = sha1(filter_input(INPUT_GET, 'senha', FILTER_SANITIZE_SPECIAL_CHARS));
$ddd = filter_input(INPUT_GET, 'ddd', FILTER_SANITIZE_SPECIAL_CHARS);
$telefone = filter_input(INPUT_GET, 'telefone', FILTER_SANITIZE_SPECIAL_CHARS);
$endereco = utf8_decode(filter_input(INPUT_GET, 'endereco', FILTER_SANITIZE_SPECIAL_CHARS));
$numero = filter_input(INPUT_GET, 'numero', FILTER_SANITIZE_SPECIAL_CHARS);
$complemento = utf8_decode(filter_input(INPUT_GET, 'complemento', FILTER_SANITIZE_SPECIAL_CHARS));
$bairro = utf8_decode(filter_input(INPUT_GET, 'bairro', FILTER_SANITIZE_SPECIAL_CHARS));
$cep = filter_input(INPUT_GET, 'cep', FILTER_SANITIZE_SPECIAL_CHARS);
$cidade = utf8_decode(filter_input(INPUT_GET, 'cidade', FILTER_SANITIZE_SPECIAL_CHARS));
$estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_SPECIAL_CHARS);
$data1 = date("Y-m-d H:i:s");
if($nomeCompleto and $email and $senha and $ddd and $telefone and $endereco and $numero and $bairro and $cep and $cidade and $estado){
//if($email){
    $verificar = mysqli_query($con,"SELECT * FROM profissional "
    . "WHERE profissional_email = '$email' AND profissional_cadastro = '1'");
    $linha = mysqli_num_rows($verificar);

    if($linha){
        $id = "pc";    
        $data[] = [
            "id" => $id
        ];
    }
    else{   
        mysqli_query($con, "DELETE FROM profissional WHERE profissional_email = '$email' AND profissional_cadastro = '0'");
        $q=mysqli_query($con,"INSERT INTO profissional ("
        . "profissional_nome, "
        . "profissional_email, "
        . "profissional_senha, "
        . "profissional_ddd, "
        . "profissional_telefone, "
        . "profissional_endereco, "
        . "profissional_numero, "
        . "profissional_complemento, "
        . "profissional_bairro, "
        . "profissional_cep, "
        . "profissional_cidade, "
        . "profissional_estado, "
        . "profissional_atendimento, "
        . "profissional_passageiro, "
        . "profissional_pedido, "
        . "profissional_status, "
        . "profissional_categoria, "
        . "profissional_forma_pagamento, "
        . "profissional_maquina, "
        . "profissional_avaliacao, "
        . "profissional_cadastro, "
        . "profissional_cadastro_data)"
        . " VALUES('$nomeCompleto', "
        . "'$email', "
        . "'$senha', "
        . "'$ddd', "
        . "'$telefone', "
        . "'$endereco', "
        . "'$numero', "
        . "'$complemento', "
        . "'$bairro', "
        . "'$cep', "
        . "'$cidade', "
        . "'$estado', "
        . "'1', "
        . "'0', "
        . "'0', "
        . "'0', "
        . "'0', "
        . "'1', "
        . "'0', "
        . "'0', "
        . "'0', "
        . "'$data1')");  
        $u = mysqli_query($con,"SELECT * FROM profissional "
        . "WHERE profissional_email = '$email'");
        $rowU = mysqli_fetch_object($u);
        $id = $rowU->profissional_id;    
        $data[] = [
            "id" => $id
        ];
    }
}else{
    $id = "di";
        $data[] = [
        "id" => $id
    ];
}
echo json_encode($data);