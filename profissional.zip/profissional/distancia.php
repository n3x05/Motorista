<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$distancia = filter_input(INPUT_GET, 'distancia', FILTER_SANITIZE_SPECIAL_CHARS);
if($distancia){
    $q=mysqli_query($con,"UPDATE profissional SET "
        . "profissional_atendimento = '$distancia' "
        . "WHERE profissional_id = '$usuarioId'"
        );    
    $dist = mysqli_query($con,"SELECT * FROM profissional "
            . "WHERE profissional_id = '$usuarioId'"
            );
    $row = mysqli_fetch_object($dist);
    $profissionalAtendimento = $row->profissional_atendimento;
}else{
    $dist = mysqli_query($con,"SELECT * FROM profissional "
            . "WHERE profissional_id = '$usuarioId'"
            );
    $row = mysqli_fetch_object($dist);
    $profissionalAtendimento = $row->profissional_atendimento;    
}
$data[] = [
    "profissionalAtendimento" => $profissionalAtendimento
];
echo json_encode($data);