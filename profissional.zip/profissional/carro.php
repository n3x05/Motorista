<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$marca = filter_input(INPUT_GET, 'marca', FILTER_SANITIZE_SPECIAL_CHARS);
$modelo = filter_input(INPUT_GET, 'modelo', FILTER_SANITIZE_SPECIAL_CHARS);
$ano = filter_input(INPUT_GET, 'ano', FILTER_SANITIZE_SPECIAL_CHARS);
$placa = filter_input(INPUT_GET, 'placa', FILTER_SANITIZE_SPECIAL_CHARS);
$s = mysqli_query($con,"SELECT * FROM carro "
            . "WHERE carro_usuario = '$usuarioId'");
$linha = mysqli_num_rows($s);
if($linha){
	if($marca and $modelo and $ano and $placa){
	    $q=mysqli_query($con,"UPDATE carro SET "
		. "carro_marca='$marca', carro_modelo='$modelo', carro_ano='$ano', carro_placa='$placa' "
		. "WHERE carro_usuario = '$usuarioId'");
	    $u = mysqli_query($con,"SELECT * FROM carro "
		    . "WHERE carro_usuario = '$usuarioId'");
	    $rowU = mysqli_fetch_object($u);
	    $carroMarca = utf8_encode($rowU->carro_marca);
	    $carroModelo = utf8_encode($rowU->carro_modelo);
	    $carroAno = $rowU->carro_ano;
	    $carroPlaca = $rowU->carro_placa;
	}else{
	$row = mysqli_fetch_object($s);
	$carroMarca = utf8_encode($row->carro_marca);
	$carroModelo = utf8_encode($row->carro_modelo);
	$carroAno = $row->carro_ano;
	$carroPlaca = $row->carro_placa;
	}
}else{
    $q=mysqli_query($con,"INSERT INTO carro (carro_usuario, carro_marca, carro_modelo, carro_ano, carro_placa) VALUES('$usuarioId', '$marca', '$modelo', '$ano', '$placa')");  
}
$data[] = [
    "marca" => utf8_encode($carroMarca),
    "modelo" => utf8_encode($carroModelo),
    "ano" => $carroAno,
    "placa" => $carroPlaca
];
echo json_encode($data);