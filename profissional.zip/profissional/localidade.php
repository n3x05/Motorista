<?php
include_once '../_database/database.php';
$longitude = filter_input(INPUT_GET, 'longitude', FILTER_SANITIZE_SPECIAL_CHARS);
$latitude = filter_input(INPUT_GET, 'latitude', FILTER_SANITIZE_SPECIAL_CHARS);
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_SPECIAL_CHARS);
mysqli_query($con,"UPDATE profissional SET "
        . "profissional_latitude = '$latitude', profissional_longitude = '$longitude' "
        . "WHERE profissional_id = '$id'"
        );
$s = mysqli_query($con,"SELECT * FROM profissional "
        . "WHERE profissional_id = '$id'"
        );
$row = mysqli_fetch_object($s);
$pedido = $row->profissional_pedido;
$p = mysqli_query($con,"SELECT * FROM pedido "
        . "WHERE pedido_id = '$pedido'"
        );
$rowPedido = mysqli_fetch_object($p);
$usuario = mysqli_query($con,"SELECT * FROM usuario "
        . "WHERE usuario_id = '$rowPedido->pedido_usuario'"
        );
$rowUsuario = mysqli_fetch_object($usuario);
$data[] = [
    "id" => $row->profissional_id,
    "nome" => utf8_encode($row->profissional_nome),
    "usuarioLatitude" => $rowPedido->pedido_usuario_latitude,
    "usuarioLongitude" => $rowPedido->pedido_usuario_longitude,
    "pedido" => $pedido,
    "preco" => $rowPedido->pedido_valor,
    "pedidoUsuario" => $rowPedido->pedido_usuario,
    "nomeUsuario" => utf8_encode($rowUsuario->usuario_nome),
    "pedidoUsuarioOrigem" => html_entity_decode(utf8_encode($rowPedido->pedido_usuario_origem), ENT_QUOTES),
    "pedidoUsuarioDestino" => html_entity_decode(utf8_encode($rowPedido->pedido_usuario_destino), ENT_QUOTES)
];
echo json_encode($data);
mysqli_free_result($s);
mysqli_free_result($p);
mysqli_free_result($usuario);
mysqli_close($con);