<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$pedidoId = filter_input(INPUT_GET, 'pedidoId', FILTER_SANITIZE_SPECIAL_CHARS);
$q = mysqli_query($con, "SELECT * "
        . "FROM pedido "
        . "WHERE pedido_id = '$pedidoId'"
);
$row = mysqli_fetch_object($q);
$pedidoStatus = $row->pedido_status;
if ($pedidoStatus === "0") {
    mysqli_query($con, "UPDATE profissional SET "
            . "profissional_pedido = '0', "
            . "profissional_status = '0', "
            . "profissional_passageiro = '0' "
            . "WHERE profissional_id = '$usuarioId'"
    );
    mysqli_query($con, "UPDATE pedido SET "
            . "pedido_status = '4' "
            . "WHERE pedido_id = '$pedidoId'"
    );
    $cancelar = "0";
    $data[] = [
        "cancelar" => $cancelar
    ];
    echo json_encode($data);
}