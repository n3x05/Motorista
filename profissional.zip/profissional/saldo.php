<?php
include_once '../_database/database.php';
$usuarioId = filter_input(INPUT_GET, 'usuarioId', FILTER_SANITIZE_SPECIAL_CHARS);
$dados1 = mysqli_query($con, "SELECT * FROM pedido WHERE pedido_profissional = '$usuarioId'");
$dados2 = mysqli_fetch_object($dados1);
$pag1 = mysqli_query($con, "SELECT SUM(pagamento_valor) as pagamentoValor FROM pagamento WHERE pagamento_profissional = '$usuarioId'");
$pag2 = mysqli_fetch_object($pag1);
$pag = number_format($pag2->pagamentoValor, 2);
$saldo1 = mysqli_query($con, "SELECT SUM(pagamento_valor) as pagamentoValor FROM pagamento WHERE pagamento_profissional = '$usuarioId' AND pagamento_status='1'");
$saldo2 = mysqli_fetch_object($saldo1);
$saldo = number_format($saldo2->pagamentoValor, 2);
$proc1 = mysqli_query($con, "SELECT SUM(pedido_valor) * AVG(pedido_porcentagem)/100 as valor, SUM(pedido_valor) as pedidoValor FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_pagamento != '0'");
$proc2 = mysqli_fetch_object($proc1);
$processado = number_format($proc2->pedidoValor, 2);
$pend1 = mysqli_query($con, "SELECT SUM(pedido_valor) * AVG(pedido_porcentagem)/100 as valor FROM pedido WHERE pedido_profissional = '$usuarioId' AND pedido_status = '1' AND pedido_pagamento = '0'");
$pend2 = mysqli_fetch_object($pend1);
$pendente = number_format($pend2->valor + $proc2->valor, 2);
$liberacao = number_format($processado - $pendente - $pag, 2);
$data[] = [
    "saldo" => $saldo,
    "liberacao" => $liberacao,
    "totalDebito" => $pendente
];
echo json_encode($data);